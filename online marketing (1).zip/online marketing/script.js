// Product filtering by search
const searchBar = document.getElementById('search-bar');
const productItems = document.querySelectorAll('.product-item');

searchBar.addEventListener('input', function () {
  const query = searchBar.value.toLowerCase();
  productItems.forEach(item => {
    const name = item.querySelector('h3').textContent.toLowerCase();
    item.style.display = name.includes(query) ? '' : 'none';
  });
});

// Sample Reviews and Ratings System
document.querySelectorAll('.review-button').forEach(button => {
  button.addEventListener('click', () => {
    alert('Displaying reviews for this product.');
  });
});
